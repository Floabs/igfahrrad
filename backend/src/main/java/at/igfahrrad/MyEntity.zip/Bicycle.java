package at.igfahrrad;

public class Bicycle {
    public String name = "Velo";
    public String description = "";
    public String price = "dgtrf";
    public String type = "";
    public String image = "";
}
