package at.igfahrrad;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
public class BicycleRepository {
    
    public static final Path FILEPATH = Path.of("bikes.json"); 

    public Bicycle[] load() throws IOException {
        var jason = Files.readString(FILEPATH);
        var mapper = new ObjectMapper();
        var bicycles = mapper.readValue(jason, Bicycle[].class);
        return bicycles;
    }
    public Bicycle[] add (Bicycle bicycle) throws IOException {
        var bicycles = this.load();
        var newBicyles = new Bicycle[bicycles.length+1];
        int i = 0;
        for(Bicycle bike:bicycles) {
            newBicyles[i] = bike;
            i++; 
        }
        newBicyles[i] = bicycle;

        return newBicyles;
    }

    public Bicycle[] deleteBicycle(Bicycle bicycle) throws IOException {
        var currentBicycles = this.load();
        List<Bicycle> bicycleList = new ArrayList<>();
        for (Bicycle bike : currentBicycles) {
            if (!bike.name.equals(bicycle.name)) {
                bicycleList.add(bike);
            }
        }
        if (bicycleList.size() == currentBicycles.length) {
            System.out.println("Bike not found");
            return currentBicycles;
        }
        var updatedBicycles = bicycleList.toArray(new Bicycle[0]);
        return updatedBicycles;
    }
    public void updateBicyclesJson(Bicycle[] bicycles) throws IOException {
        var mapper = new ObjectMapper();
        var json = mapper.writeValueAsString(bicycles);
        Files.writeString(FILEPATH, json);
    }
}
